import menu.MenuRun;
import password.Password;

public class Main {

    void run() {
        new Password().checkPassword();
        new MenuRun().menuRun();
    }

    public static void main(String[] args) {
        new Main().run();
    }
}
